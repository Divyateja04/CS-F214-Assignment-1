var struct_tree_node =
[
    [ "left", "struct_tree_node.html#a99fb5e0be96ed75527d53c3747f93c2d", null ],
    [ "right", "struct_tree_node.html#a02b3bbe1406cbe1e9f0bc9cc1d5ea247", null ],
    [ "val", "struct_tree_node.html#a0f88d66987f307f00e5868889c52df87", null ]
];