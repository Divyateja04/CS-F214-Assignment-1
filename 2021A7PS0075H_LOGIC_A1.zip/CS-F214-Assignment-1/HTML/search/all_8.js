var searchData=
[
  ['task_200_3a_20initializing_20all_20the_20constants_20and_20libraries_0',['Task 0: Initializing all the constants and libraries',['../md__task0.html',1,'']]],
  ['task_201_3a_20to_20convert_20infix_20to_20preorder_1',['Task 1: To convert infix to preorder',['../md__task1.html',1,'']]],
  ['task_202_3a_20to_20convert_20prefix_20to_20tree_2',['Task 2: To convert prefix to tree',['../md__task2.html',1,'']]],
  ['task_203_3a_20function_20to_20traverse_20through_20the_20tree_20in_20order_3',['Task 3: Function to traverse through the tree in order',['../md__task3.html',1,'']]],
  ['task_204_3a_20height_20of_20the_20parse_20tree_4',['Task 4: Height of the Parse Tree',['../md__task4.html',1,'']]],
  ['task_205_3a_20evaluating_20the_20truth_20value_20of_20propositional_20logic_20formula_20in_20a_20bottoms_20up_20fashion_5',['Task 5: Evaluating the truth value of propositional logic formula in a bottoms up fashion',['../md__task5.html',1,'']]],
  ['task_206_3a_20analysis_20and_20graphs_6',['Task 6: Analysis and Graphs',['../md__task6.html',1,'']]],
  ['task_2ec_7',['Task.c',['../_task_8c.html',1,'']]],
  ['task0_2emd_8',['Task0.md',['../_task0_8md.html',1,'']]],
  ['task1_2emd_9',['Task1.md',['../_task1_8md.html',1,'']]],
  ['task2_2emd_10',['Task2.md',['../_task2_8md.html',1,'']]],
  ['task3_2emd_11',['Task3.md',['../_task3_8md.html',1,'']]],
  ['task4_2emd_12',['Task4.md',['../_task4_8md.html',1,'']]],
  ['task5_2emd_13',['Task5.md',['../_task5_8md.html',1,'']]],
  ['task6_2emd_14',['Task6.md',['../_task6_8md.html',1,'']]],
  ['top_15',['top',['../_task_8c.html#af93f4f37fc2ad9c37af4a715423b110c',1,'Task.c']]],
  ['treenode_16',['TreeNode',['../struct_tree_node.html',1,'TreeNode'],['../_task_8c.html#aba028b9fa75702386100892732a4e800',1,'TreeNode():&#160;Task.c']]]
];
