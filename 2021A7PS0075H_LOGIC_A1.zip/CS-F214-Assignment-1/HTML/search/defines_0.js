var searchData=
[
  ['max_0',['max',['../_task_8c.html#a2e1da8593b0244d8e9e3b84ef7b35e73',1,'Task.c']]]
];
