var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['recursivetruthevaluator_1',['recursiveTruthEvaluator',['../_task_8c.html#af8cfe1853f9906165524e57444d88f47',1,'Task.c']]],
  ['returnvalueforletter_2',['returnValueForLetter',['../_task_8c.html#a7077de4bd3e0000ec5bf0f35b6a0a494',1,'Task.c']]],
  ['right_3',['right',['../struct_tree_node.html#a02b3bbe1406cbe1e9f0bc9cc1d5ea247',1,'TreeNode']]]
];
