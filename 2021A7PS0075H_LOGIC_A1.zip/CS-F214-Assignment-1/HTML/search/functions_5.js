var searchData=
[
  ['stackisempty_0',['stackIsEmpty',['../_task_8c.html#a328d06e919f031e5305bf079c3b1ec32',1,'Task.c']]],
  ['stackpop_1',['stackPop',['../_task_8c.html#aed34a437ccad598623ff35ce06b759dc',1,'Task.c']]],
  ['stackpush_2',['stackPush',['../_task_8c.html#aed61586067826b285a214c9643d2c796',1,'Task.c']]]
];
