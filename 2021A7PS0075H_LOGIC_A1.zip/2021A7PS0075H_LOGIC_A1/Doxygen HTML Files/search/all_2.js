var searchData=
[
  ['left_0',['left',['../struct_tree_node.html#a99fb5e0be96ed75527d53c3747f93c2d',1,'TreeNode']]],
  ['letters_1',['letters',['../_task_8c.html#a2151bd1c2ce92daf32e77205817082c9',1,'Task.c']]]
];
