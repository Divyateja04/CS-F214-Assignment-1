var searchData=
[
  ['calcmax_0',['calcMax',['../_task_8c.html#a8afd80be6cfb73e36bf48de6a8c1dd6c',1,'Task.c']]],
  ['convertpreordertotree_1',['convertPreOrderToTree',['../_task_8c.html#a361116e1fb6837a1384c240b3659df98',1,'Task.c']]]
];
