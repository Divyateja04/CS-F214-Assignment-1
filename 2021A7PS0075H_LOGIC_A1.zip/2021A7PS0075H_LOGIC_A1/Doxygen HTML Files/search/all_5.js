var searchData=
[
  ['printinorder_0',['printInOrder',['../_task_8c.html#a313ba20caa46358af4cc9e665ec9b532',1,'Task.c']]],
  ['priority_1',['priority',['../_task_8c.html#af2203c8d92ff1e4f0321eb566de02ffa',1,'Task.c']]]
];
