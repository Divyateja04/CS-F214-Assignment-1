var searchData=
[
  ['recursivetruthevaluator_0',['recursiveTruthEvaluator',['../_task_8c.html#af8cfe1853f9906165524e57444d88f47',1,'Task.c']]],
  ['returnvalueforletter_1',['returnValueForLetter',['../_task_8c.html#a7077de4bd3e0000ec5bf0f35b6a0a494',1,'Task.c']]]
];
