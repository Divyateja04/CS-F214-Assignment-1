var searchData=
[
  ['infixtoprefix_0',['inFixToPreFix',['../_task_8c.html#a0e688bcec659f9871c626ad8d4a99457',1,'Task.c']]]
];
