var searchData=
[
  ['stack_0',['stack',['../_task_8c.html#ae24cff811e071e4fe46eff231506df71',1,'Task.c']]]
];
