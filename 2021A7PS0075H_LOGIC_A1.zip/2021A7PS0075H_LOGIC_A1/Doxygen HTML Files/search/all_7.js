var searchData=
[
  ['stack_0',['stack',['../_task_8c.html#ae24cff811e071e4fe46eff231506df71',1,'Task.c']]],
  ['stackisempty_1',['stackIsEmpty',['../_task_8c.html#a328d06e919f031e5305bf079c3b1ec32',1,'Task.c']]],
  ['stackpop_2',['stackPop',['../_task_8c.html#aed34a437ccad598623ff35ce06b759dc',1,'Task.c']]],
  ['stackpush_3',['stackPush',['../_task_8c.html#aed61586067826b285a214c9643d2c796',1,'Task.c']]]
];
