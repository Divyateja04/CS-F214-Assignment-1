var searchData=
[
  ['right_0',['right',['../struct_tree_node.html#a02b3bbe1406cbe1e9f0bc9cc1d5ea247',1,'TreeNode']]]
];
